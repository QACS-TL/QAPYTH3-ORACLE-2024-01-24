import requests
import sys


def get_customers():
    base_url = r"http://127.0.0.1:5000/customers"
    try:
        customers = requests.get(base_url)
        c_data = customers
    except Exception as err:
        # if there was an error opening the url then return error
        print(f"Error: {err.args}", file=sys.stderr)
        return "Error opening url"

    return c_data


custs = get_customers()
for customer in custs:
    print(customer)
