#! /usr/bin/python

########################################################
# Insert your TIMER FUNCTIONS here


start_timer()
lines = 0
for row in open("words"):
    lines += 1
    
end_timer()
print("Number of lines:", lines)