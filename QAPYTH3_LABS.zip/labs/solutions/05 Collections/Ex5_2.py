#!/usr/local/bin/python
tup = 'Hello'
print (len(tup))

tup = 'Hello',
print (len(tup))
