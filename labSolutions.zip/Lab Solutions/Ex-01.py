#Question 1
# Open pycharm terminal and type python -V

#Question 2
first = 'Fred'
last = 'Bloggs'
print(first, last)

#Question 3
import sys
print(sys.platform)
