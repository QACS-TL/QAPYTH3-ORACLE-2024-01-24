import sys
sys.path.append('./Finance')
import Finance
print(Finance.banking.deposit(balance=40))

import sys, math

print(f"2 cubed is {math.pow(2, 3)}")
print(f"Current path: {sys.path}")

import mymodule_win32 as mymodule
print(mymodule.attribute)
print(mymodule.my_func())
