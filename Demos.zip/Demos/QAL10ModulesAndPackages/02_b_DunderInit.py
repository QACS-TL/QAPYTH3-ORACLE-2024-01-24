# import Finance
# import Finance.QATraining

# print(Finance.banking.deposit(balance=10))

# import sys
# sys.path.append('./Finance2')  # <<< Needed for import Finance to work
# import Finance2
from Finance2 import QATraining

# print(Finance2.banking.deposit(balance=10))
print(QATraining.deposit(balance=10))
