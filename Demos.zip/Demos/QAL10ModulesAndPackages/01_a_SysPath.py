import sys
sys.path.append('./Finance')
import Finance
# import Finance.QATraining

print(sys.path)
print(Finance.banking.deposit(balance=10))
# print(Finance.QATraining.deposit(balance=10))
