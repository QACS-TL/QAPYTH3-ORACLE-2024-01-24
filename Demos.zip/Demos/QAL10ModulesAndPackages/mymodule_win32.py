def my_func():
    return "Hello from my_func"

attribute = "I'm an attribute"
