""" Test Cases for Calculator app.: """
import unittest
import Calculator

class TestCalc(unittest.TestCase):
    def test_add(self):
        self.assertEqual(7, Calculator.add(4, 3))
        self.assertEqual(60, Calculator.add(10, 20, 30))
        return None

    def test_mul(self):
        self.assertEqual(12, Calculator.mul(4, 3))
        return None

    def test_div(self):
        self.assertEqual(1.333, Calculator.div(4, 3))

        with self.assertRaises(Exception) as context:
            Calculator.div(4, 0)
        self.assertEqual('Divisor must be zero', str(context.exception))
        return None


