""" Test Cases for Calculator app.: """
import Calculator

def test_add():
    assert Calculator.add(4, 3) == 7, "Error should return 7"
    assert Calculator.add(10, 20, 30) == 60, "Error should return 60"
    return None

def test_mul():
    assert Calculator.mul(4, 3) == 12, "Error should return 12"
    return None

def test_div():
    assert Calculator.div(4, 3), "Error should return '1.333'"
    return None

def main():
    """ Execute Test functions """
    test_add()
    test_mul()
    test_div()
    print("Everything passed")
    return None

if __name__ == "__main__":
    main()
