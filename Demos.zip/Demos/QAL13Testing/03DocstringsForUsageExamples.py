
"""
     Calculator program with add, subtract, multiply,
     and divide functions.
"""

def add(*args):
    """ Returns the sum of all arguments 
    >>> add(4, 3)
    7
    >>> add(10, 20, 30)
    60
    """
    total = 0
    for num in args:
        total += num
    return total

def sub(x, y):
    return x - y

def mul(*args):
    """ Returns the product of all parameters.
    >>> mul(4, 3)
    12
    """
    total = 1
    for num in args:
      total *= num
    return total

def div(x, z):
    """ Returns x divided by z, as a float to 3 decimal places.
    >>> div(4, 3)
    1.333
    """
    return float(f"{x/z:.3f}")

def main():
    print(f"4 + 3 = {add(4, 3)}")
    print(f"4 - 3 = {sub(4, 3)}")
    print(f"4 * 3 = {mul(4, 3)}")
    print(f"4 / 3 = {div(4, 3)}")


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    main()

