""" Test Cases for Calculator app.: """
import unittest
import Calculator

class TestCalc(unittest.TestCase):
    def test_add(self):
        assert Calculator.add(4, 3) == 7, "Error should return 7"
        assert Calculator.add(10, 20, 30) == 60, "Error should return 60"
        return None

    def test_mul(self):
        assert Calculator.mul(4, 3) == 12, "Error should return 12"
        return None

    def test_div(self):
        assert Calculator.div(4, 3) == 1.333, "Error should return '1.333'"
        return None


