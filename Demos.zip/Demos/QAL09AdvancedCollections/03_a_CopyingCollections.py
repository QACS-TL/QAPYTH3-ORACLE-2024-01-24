fruit = ['Apple', 'Pear', 'Orange']
lunch = fruit
lunch[1] = 'Eggs'
print(fruit)

print()

# For a sequence take a slice
# Expected output:
# fruit: ['Apple', 'Pear', 'Orange']
# lunch: ['Apple', 'Eggs', 'Orange']
fruit = ['Apple', 'Pear', 'Orange']
lunch = fruit[:]
lunch[1] = 'Eggs'
print('fruit:', fruit, '\nlunch:', lunch)

print()

# A slice is still a shallow copy
# Expected output:
# fruit: ['knife', 'plate', ['Apple', 'Eggs', 'Orange']]
# lunch: ['knife', 'plate', ['Apple', 'Eggs', 'Orange']]
fruit = ['knife', 'plate', ['Apple', 'Pear', 'Orange']]
lunch = fruit[:]
lunch[2][1] = 'Eggs'
print('fruit:', fruit, '\nlunch:', lunch)

print()

# Deep copy
# Expected output:
# fruit: ['knife', 'plate', ['Apple', 'Pear', 'Orange']]
# lunch: ['knife', 'plate', ['Apple', 'Eggs', 'Orange']]
import copy

fruit = ['knife', 'plate', ['Apple', 'Pear', 'Orange']]
lunch = copy.deepcopy(fruit)
lunch[2][1] = 'Eggs'
print('fruit:', fruit, '\nlunch:', lunch)


