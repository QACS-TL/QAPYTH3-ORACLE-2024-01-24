def csv_reader(file_name):
    for row in open(file_name, "r"):
        yield row

row_count = 0;
for row in csv_reader("SampleCSVFile_11kb.csv"):
    row_count += 1
    cols = row.split()
    for i, s in enumerate(cols, 0):
        print(f"Line: {row_count}, Column: {i}, Value: {s}")

