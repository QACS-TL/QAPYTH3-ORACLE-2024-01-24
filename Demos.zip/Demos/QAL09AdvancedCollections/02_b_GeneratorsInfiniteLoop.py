def infinite_sequence():
    num = 0
    while True:
        yield num
        num += 1


for i in infinite_sequence(): # infinite if you're not careful!'
    print(i, end=" ")
    if i >= 1000:
        exit(0)

gen = infinite_sequence()
while True:
    n = next(gen)
    print(n)
    if n % 100 == 0:
        if input("Q to quit: ").upper() == "Q":
            exit(0)

