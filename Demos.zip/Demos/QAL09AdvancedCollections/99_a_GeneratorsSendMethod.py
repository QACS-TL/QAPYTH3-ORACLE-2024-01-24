import glob
import os
import os.path

# Data can be returned to the generator using send.
def get_dir(path):
    while True:
        pattern = os.path.join(path,'*')
        path = None
        for file in glob.iglob(pattern):
            if os.path.isdir(file):
                path = yield file
                if path: break

        if not path: break
    return

gen = get_dir('C:/Windows')

print(next(gen))
print(next(gen))
print(gen.send('C:/ProgramData'))  # <<<<<<<<<<<<<<<
print(next(gen))
