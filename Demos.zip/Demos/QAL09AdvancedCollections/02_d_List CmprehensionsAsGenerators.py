import os.path
import glob

def get_dir(path):
    pattern = os.path.join(path, '*')
    for file in glob.iglob(pattern):
        if os.path.isdir(file):
            yield file

def get_dirLC(path):
    pattern = os.path.join(path, '*')
    return (file
            for file in glob.iglob(pattern)
            if os.path.isdir(file))

for dir in get_dirLC('C:\Windows'):
    print(dir)
