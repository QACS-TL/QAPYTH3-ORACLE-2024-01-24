import os.path
import glob

def get_dir(path):
    pattern = os.path.join(path, '*')
    for file in glob.iglob(pattern):
        if os.path.isdir(file):
            yield file

for dir in get_dir('C:\Windows'):
    print(dir)

print("------------------------------------------------------")

dirs = list(get_dir('C:\Windows'))
for dir in dirs:
    print(dir)

