from abc import *


class Vehicle(metaclass = ABCMeta):
    def __init__(self, reg="A1"):
        self._reg = reg

    @abstractmethod
    def getReg(self):
        pass


class Car(Vehicle):
    def __init__(self, reg="C1", wheels=4):
        super().__init__(reg)
        self._wheels = wheels

    def getReg(self):
        return self._reg

    def getNumberOfWheels(self):
        return self._wheels


class Motorbike(Vehicle):
    def __int__(self, reg="M1", wheels=2):
        super().__init__(reg)
        self._wheels = wheels

    def getReg(self):
        return self._reg

    def getNumberOfWheels(self):
        return self._wheels


beepbeep = Car("AA11 XYZ", 3)
print(beepbeep.getReg())

NoGo = Vehicle()  # Can't be done because class is abstract (by virtue of fact it contains n abstract method
print(NoGo.getReg())
