class Person:
   def __init__(self, name, gender):
       self._name = name
       self._gender = gender.upper()

   def __str__(self):
       return "Name: " + self._name+ \
              " Gender: " + self._gender


class Employee(Person):

    def __init__(self, name, gender, dept):
        super().__init__(name, gender)
        self._dept = dept



mp = Person("Theresa May", 'f')
me = Employee("Fred Bloggs", 'm', 'IT')

if isinstance(mp, Employee):
    print(mp, "isa Employee!")

if isinstance(mp, Person):
    print(mp, "isa Person!")

if issubclass(Employee, Person):
    print("Employee is a subclass of Person")

if isinstance(me, Employee):
    print(me, "isa Employee!")

if isinstance(me, Person):
    print(me, "isa Person!")


