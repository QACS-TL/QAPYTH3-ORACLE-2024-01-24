import datetime


class Date:

    year = 0
    month = 0
    day = 0

    def __init__(self, day=0, month=0, year=0):
        self._day   = day
        self._month = month
        self._year = year
        Date.year = year
        Date.month = month
        Date.day = day

    def __str__(self):
        return "%02d/%02d/%d" % (
               self._day, self._month, self._year)

    @classmethod
    def getYMD(cls):
        return f"{Date.year:04d}/{Date.month:02d}/{Date.day:02d}"

    def _validate_date(self):
        try:
            date_text = f"{self._year}-{self._month}-{self._day}"
            datetime.date.fromisoformat(date_text)
        except ValueError:
            raise ValueError("Incorrect data format, should be YYYY-MM-DD")

    def __add__(self, value):
        retn = Date(self._day, self._month, self._year)
        retn._day = retn._day + value
        retn._validate_date()
        return retn
        
today = Date(9, 11, 2015)
print(today)
print(Date.getYMD())
try:
    tomorrow = today + 1
    print(tomorrow)
    print(Date.getYMD())  # unchanged


except ValueError as e:
    print(e)
    exit(2)


