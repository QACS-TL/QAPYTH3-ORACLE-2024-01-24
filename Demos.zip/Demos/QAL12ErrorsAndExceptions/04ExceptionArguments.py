import sys
try:
    f = open("foo")
except FileNotFoundError as err:
    print("Could not open",
          err.filename, err.args[1],
          file=sys.stderr)

    print("Exception arguments:", err.args,
          file=sys.stderr)

print("We will see this")
