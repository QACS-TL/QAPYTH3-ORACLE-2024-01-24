filename = "foo"
try:
    f = open(filename)
except FileNotFoundError:
    errmsg = filename + " not found"
except (TypeError, ValueError):
    errmsg = "Invalid filename"
# ...
print("Stuff done here if error occurs")

if errmsg != "":
    exit(errmsg)

print("Stuff NOT done here if error occurs")
