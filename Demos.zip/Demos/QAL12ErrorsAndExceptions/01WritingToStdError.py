import sys

something_nasty = True

if something_nasty:
    sys.stderr.write("Invalid types compared")  # prints in red (PyCharm)
    exit(1)

# OR:
print("Invalid types compared", file=sys.stderr)
