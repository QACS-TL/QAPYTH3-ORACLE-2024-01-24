def my_func(*arguments):
    assert all(arguments), 'False argument in my_func'
    # ...

my_func('Tom', 'X', 42)  # Empty string or zero will cause assert to fail. i.e. any argument that is False
