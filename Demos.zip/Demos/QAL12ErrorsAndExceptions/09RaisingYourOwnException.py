import sys

class MyError(Exception):
    pass

def my_func(*arguments):
    if not all(arguments):
        raise MyError('False argument in my_func')

try:
    my_func('Tom', '', 42)
except MyError as err:
    print('Oops:', err, file=sys.stderr)
