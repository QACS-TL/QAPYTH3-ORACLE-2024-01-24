stein = 1
pint = 1

stein = stein + pint
print(stein)

stein += pint
print(stein)

# Also works for -=, *=, /= and %= (gives modulus, the remainder when doing integer division)
