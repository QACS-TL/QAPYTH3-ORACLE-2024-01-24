# What is wrong with the following code?
# age = input("Please enter your age: ")
# print(f"On your next birthday you will be {age + 1} years old")


# What kind of lists are the following?
cars = "Ford", "Vauxhall", "Renault", "Seat"

trees = ["Elm", "Oak", "Rowan", "Elm"]

rocks = {"Jasper", "Bauxite", "Feldspar", "Chalk", "Jasper"}

elements = {1: "Hydrogen", 2: "Helium", 3: "Lithium", 4: "Beryllium", 1: "Hydrogen"}

windspeeds = ("Calm", "Light Air", "Light Breeze", "Moderate Breeze", "Fresh Breeze", "Strong Breeze", "Near Gale", "Gale", "Strong Gale", "Storm", "Violent Storm", "Hurricane")

print(cars[0])
print(cars[1])
print(cars[4])

print(rocks[0])

print(elements[1])
print(elements[0])

