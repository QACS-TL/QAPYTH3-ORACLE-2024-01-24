cheese = ['Cheddar', 'Stilton', 'Cornish Yarg']
for i in range(0, 3):
    print(cheese[i])
cheese[-1] = 'Red Leicester'
print(cheese)


# Multidimensional
cheese = ['Cheddar', ['Camembert', 'Brie'], 'Stilton']
print(cheese[1][0])
