

def my_func():
    print("Hello")
    print("Everyone")


my_func()



def my_func(name):
    print("Hello")
    print(name)


my_func("Bob")
