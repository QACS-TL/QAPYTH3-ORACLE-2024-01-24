# Note lines 4 and 9 are identical but are they doing the same thing?
def my_func():
    print("Hello from my func")


def bark(number_of_times):
    for i in range(0, number_of_times):
        print("woof")

a = 42
b = 9
c = a + b
print(c)


bark(4)

a = 'Hello '
b = 'World!'
c = a + b
print(c)
print(c.upper())
print(type(a))
