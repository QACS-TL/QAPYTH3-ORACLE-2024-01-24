my_var = 10
print(my_var)

name = "pete"
print(name.upper())

# del my_var

# print(my_var)
