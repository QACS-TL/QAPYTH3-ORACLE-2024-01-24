import re
quote = "Here's looking at you kid"
x = re.split("\s", quote, 3)
print(x)