import random

lottery_number = random.randint(1,10)
print(lottery_number)