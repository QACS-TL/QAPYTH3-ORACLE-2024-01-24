s6 = {23, 42, 66, 123}
s7 = {123, 56, 27, 42}

print(s6 & s7)  # intersection
print(s6 | s7)  # union
print(s6 - s7)  # difference
print(s6 ^ s7)  # symmetric difference
