
fruit = "banana"
print("The answer is", 42, "always", fruit, sep=': ', end='')
print("(I think)")

print("The answer is", 42, "always", end='')
print("(I think)")

print("The answer is", 42, "always")
print("(I think)")

print(f"my favourite fruit are {fruit}s", end=" * ")
print(f"my favourite fruit are {fruit}s")
