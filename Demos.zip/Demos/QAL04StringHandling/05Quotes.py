print('hello\nworld')
print("hello\nworld")


html = """ 
<tr> 
      <td><font color="#690000"><b>Username :</b></font></td> 
      <td><input type='textbox' name='username'></td> 
</tr> 
"""
print(html)

file = """C:\\QA\\Python\\PYTHB\\"""
print(file)