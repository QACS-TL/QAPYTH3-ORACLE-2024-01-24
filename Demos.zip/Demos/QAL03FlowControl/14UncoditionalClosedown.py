import sys

for i in range(0,10):
    if i == 5:
        sys.exit("goodbye")
    print(i)
