# What is wrong with the following code?
# age = input("Please enter your age: ")
# print(f"On your next birthday you will be {age + 1} years old")


# What kind of lists are the following?
cars = "Ford", "Vauxhall", "Renault", "Seat"

trees = ["Elm", "Oak", "Rowan", "Elm"]

rocks = {"Jasper", "Bauxite", "Feldspar", "Chalk", "Jasper"}

elements = {1: "Hydrogen", 2: "Helium", 3: "Lithium", 4: "Beryllium", 1: "Hydrogen"}

windspeeds = ("Calm", "Light Air", "Light Breeze", "Moderate Breeze", "Fresh Breeze", "Strong Breeze", "Near Gale", "Gale", "Strong Gale", "Storm", "Violent Storm", "Hurricane")

if "Jasper" in rocks:
    print("Jasper is in rocks!")

possible_tree = input("Please enter the name of a possible tree")
if possible_tree in trees:
    print(possible_tree + " is in trees!")
else:
    print(possible_tree + " is not in trees")



