for i in range(10):
    print(i)

import sys

for idx, arg in enumerate(sys.argv):
    print('index:', idx, 'argument:', arg)


# To run this enter the following at the terminal:
# Python 09forloops.py Monday Tuesday Wednesday
