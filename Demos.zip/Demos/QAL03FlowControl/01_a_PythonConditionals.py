i = 0

if i < 10:
    print("That’s low")
elif i < 5:
    print("That’s lower")
else:
    print("That’s high")

lista = [1, 2, 3, "eggs"]
listb = [1, 2, 3, "eggs"]
if lista == listb:
    print("Same!")

if "eggs" in lista:
    print("It eggists!")


http_code = "418"

match http_code:
    case "200":
        print("OK")
    case "404":
        print("Not Found")
    case "418":
        print("Some other problem")
    case _:
        print("Code not found")



