def result(grade,score=50,feedback="Well Done!"):
    print("You scored",score,"which is a grade",grade,feedback)

result("C")
result("A",87)
result("E",12,"Must do Better!")
