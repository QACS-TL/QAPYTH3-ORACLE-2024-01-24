def my_func1(val, lista=[]):
    lista.append(val)
    print("value of lista is:", lista)
    return

my_list = []
my_func1(42, my_list)
my_func1(37, my_list)
my_func1(99, my_list)


def my_func2(val, lista=None):
    if lista == None:
        lista = []
    lista.append(val)
    print("value of lista is:", lista)
    return


my_func2(42)
my_func2(37)
my_func2(99)

